# Simple as it gets
def add(event, context):
    return event['a'] + event['b']
